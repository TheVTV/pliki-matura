#include <iostream>
#include <fstream>

using namespace std;
int suma (int a)
{
    int s=0;
    int i=2;
    while(a!=1)
    {
        while(a%i==0)
        {
        s+=i;
        a/=i;
        }
    i++;
    }
    return s;
}
int main()
{
    ifstream we ("kebab_przyklad.txt");
    ofstream wy ("wykiki3.txt");
    int t[50][2];
    int l=1;
    int a, b, max=0;
    for(int i=0; i<50; i++)
        {we>>t[i][0];
        if(t[i][0]!=suma(t[i][0]))
            {   l++;
                a=t[i][0];
                b=suma(t[i][0]);
                while(a!=b)
                {   a=suma(a);
                    b=suma(b);
                    l++;
                }
            }
        if(l>max)
                max=l;
        t[i][1]=l;
        }
    wy<<"   3.1"<<endl<<max<<endl;
    for(int i=0; i<50; i++)
        if(t[i][1]==max)
            wy<<t[i][0]<<endl;

    return 0;
}
