def suma_rozkladu(c1):
    suma = 0
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                suma += i

    return suma

def kebabuj(c1):
    suma = 0
    ostatnia = 0
    obecna = c1
    dlugosc_procesu = 1
    while obecna != ostatnia:
        dlugosc_procesu+=1
        suma_r = suma_rozkladu(obecna)
        suma += suma_r
        ostatnia = obecna
        obecna = suma_r
    return dlugosc_procesu, suma + c1


with open("kebab_przyklad.txt") as f:
    liczby = [int(x) for x in f.read().split()]

def ile_dzielnikow(c1):
    ile = 0
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                ile += 1

    return ile

ile_palindrom = 0
ile_pierwsze = 0

for liczba in liczby:
    _, zkebabowana = kebabuj(liczba)
    if str(zkebabowana) == str(zkebabowana)[::-1]: ile_palindrom += 1
    if zkebabowana > 1 and ile_dzielnikow(zkebabowana) == 1: 
        ile_pierwsze += 1
        print(liczba,zkebabowana, suma_rozkladu(zkebabowana))

print(ile_palindrom, ile_pierwsze)