def suma_rozkladu(c1):
    suma = 0
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                suma += i

    return suma

def suma_rozkladu_wlas(c1):
    suma = 0
    c2 = c1
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                if i < c2: suma += i
    return suma

def kebabuj(c1):
    suma = 0
    ostatnia = 0
    obecna = c1
    while ostatnia != obecna:
        ostatnia = obecna
        suma_r = suma_rozkladu(obecna)
        obecna = suma_r
        suma += obecna

    return suma + c1

with open("kebab_przyklad.txt") as f:
    liczby = [int(x) for x in f.read().split("\n")]

ile_fl = 0
for liczba in liczby:
    k = kebabuj(liczba)
    if k == suma_rozkladu_wlas(k):
        ile_fl += 1

print(ile_fl)
