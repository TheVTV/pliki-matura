def suma_rozkladu(c1):
    suma = 0
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                suma += i

    return suma

def kebabuj(c1):
    suma = 0
    ostatnia = 0
    obecna = c1
    dlugosc_procesu = 1
    while obecna != ostatnia:
        dlugosc_procesu+=1
        suma_r = suma_rozkladu(obecna)
        suma += suma_r
        ostatnia = obecna
        obecna = suma_r
    return dlugosc_procesu, suma + c1


with open("kebab.txt") as f:
    liczby = [int(x) for x in f.read().split()]

max_liczby = set()
max_dlugosc_procesu = 0

for liczba in liczby:
    dlugosc_procesu, _ = kebabuj(liczba)
    if dlugosc_procesu > max_dlugosc_procesu:
        max_liczby.clear()
        max_liczby.add(liczba)
        max_dlugosc_procesu = dlugosc_procesu
    if dlugosc_procesu == max_dlugosc_procesu:
        max_liczby.add(liczba)

print(max_dlugosc_procesu)
for ml in max_liczby:
    print(ml)