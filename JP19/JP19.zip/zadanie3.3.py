

def suma_rozkladu(c1):
    suma = 0
    while c1 > 1:
        for i in range(2, c1 + 1, 1):
            if c1 % i == 0:
                c1 //= i
                suma += i
    return suma

def kebabuj(c1):
    suma = 0
    ostatnia = 0
    obecna = c1
    mm = 1 if c1 % 2 == 0 else -1
    while obecna != ostatnia:
        suma_r = suma_rozkladu(obecna)
        mm += 1 if suma_r % 2 == 0 else -1
        suma += suma_r
        ostatnia = obecna
        obecna = suma_r
    return suma + c1, mm == 0

with open("kebab_przyklad.txt") as f:
    liczby = [int(x) for x in f.read().split("\n")]

ile_mm = 0
for liczba in liczby:
    _, mm = kebabuj(liczba)
    if mm:
        ile_mm += 1

print(ile_mm)