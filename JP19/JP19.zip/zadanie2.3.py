with open("liczby.txt") as f:
    liczby = [x.split("\t") for x in f.read().split("\n") if x != ""]

dane = []

pary = {}


max_value = 0
max_liczba = ""
min_value = 10e9
min_liczba = ""


for liczba in liczby:
    a, b = liczba
    for i in range(2, 17):
        try:
            if str(int(a, i)) == str(int(b, i))[::-1]:
                liczba.append(i)
                dane.append((a,b,i))
                pary[i] = pary.get(i,0)+1

                liczba = int(a, i)
                if liczba < min_value:
                    min_liczba = a
                    min_value = liczba

                if liczba > max_value:
                    max_liczba = b
                    max_value = liczba

                break
        except:
            pass
    
print(min_liczba, max_liczba)
# print(min_value, max_value)