with open("liczby.txt") as f:
    liczby = [x.split("\t") for x in f.read().split("\n") if x != ""]
    print(liczby)

dane = []

pary = {}
liczby_p = []
for liczba in liczby:
    a, b = liczba
    for i in range(2, 17):
        try:
            if str(int(a, i)) == str(int(b, i))[::-1]:
                liczba.append(i)
                dane.append((a,b,i))
                pary[i] = pary.get(i,0)+1
                break
        except:
            pass

print(pary)