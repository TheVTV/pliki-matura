with open("liczby.txt") as f:
    znaki_p = f.read()

znaki = "0123456789ABCDEF"

suma = 0
for znak in znaki:
    suma += znaki_p.count(znak)

for znak in znaki:
    print(znak, round(10000*znaki_p.count(znak)/suma)/100)