#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

bool comp(int a, int b) {
    return a > b;
}

int suma_czynn(int n)
{
    int i=2;
    int kolejna=0;
    while(n>1) {
        if(n%i==0) {
            kolejna+=i;
            n/=i;
        }
        else
            i++;
    }

    return kolejna;
}

int kebab1(int n)
{
    int proces=2;
    int liczba_kebabowa=n;
    int pierwsza=n;
    int kolejna = suma_czynn(n);
    while(pierwsza!=kolejna) {
        proces++;
        liczba_kebabowa+=kolejna;
        pierwsza=kolejna;
        kolejna=suma_czynn(pierwsza);
    }

    liczba_kebabowa+=kolejna;
    return proces;
}

int kebab2(int n)
{
    int proces=2;
    int liczba_kebabowa=n;
    int pierwsza=n;
    int kolejna = suma_czynn(n);
    while(pierwsza!=kolejna) {
        proces++;
        liczba_kebabowa+=kolejna;
        pierwsza=kolejna;
        kolejna=suma_czynn(pierwsza);
    }

    liczba_kebabowa+=kolejna;
    return liczba_kebabowa;
}

bool czy_mm(int n)
{
    int parz=0, nieparz=0;
    int pierwsza=n;
    int kolejna = suma_czynn(n);
    while(pierwsza!=kolejna) {
        if(pierwsza%2==0)
            parz++;
        else
            nieparz++;
        pierwsza=kolejna;
        kolejna=suma_czynn(pierwsza);
    }

    /*
    if(kolejna%2==0)
            parz++;
    else
            nieparz++;
    */
    if(parz==nieparz)
        return 1;
    else
        return 0;
}

bool palindrom(int n)
{
    int oryg = n;
    int odw = 0;

    while (n > 0)
    {
        int cyfra = n % 10;
        odw = odw * 10 + cyfra;
        n /= 10;
    }

    return oryg == odw;
}

bool czy_pierw(int n)
{
    for (int i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }

    return true;
}

bool falafel(int n)
{
    int licz_dziel=0;
    for(int i=1; i<n; i++)
        if(n%i==0)
            licz_dziel+=i;
    if(licz_dziel==n)
        return 1;
    else
        return 0;
}

int main()
{
    int linia;
    std::vector<int>liczba;
    std::ifstream plik ("kebab.txt", std::ios::in);
    if(plik) {
        while (plik>>linia) {
            liczba.push_back(linia);
        }
        plik.close();
    }

    //ZAD 1
    std::cout<<"ZADANIE 3.1" <<"\n";
    std::vector<int>dlug;
    int maks=0;
    for(int i=0; i<liczba.size(); i++) {
        if(kebab1(liczba[i])>maks) {
            maks=kebab1(liczba[i]);
        }
    }

    std::cout<<maks<<"\n";
    for(int i=0; i<liczba.size();i++) {
        if(kebab1(liczba[i])==maks)
            std::cout<<liczba[i]<<"\n";
    }

    //ZAD 2
    std::cout<<"ZADANIE 3.2" <<"\n";
    int palin=0;
    int pierw=0;
    for(int i=0; i<liczba.size(); i++) {
        int n=kebab2(liczba[i]);
        if(palindrom(n))
            palin++;
        if(czy_pierw(n))
            pierw++;
    }

    std::cout<<palin<<" "<<pierw<<"\n";

    //ZAD 3
    std::cout<<"ZADANIE 3.3" <<"\n";
    int mieciany=0;
    for(int i=0; i<liczba.size(); i++) {
        if(czy_mm(kebab2(liczba[i])))
            mieciany++;
    }

    std::cout<<mieciany<<"\n";

    //ZAD 4
    std::cout<<"ZADANIE 3.4" <<"\n";
    int falafele=0;
    for(int i=0; i<liczba.size(); i++)
        if(falafel(kebab2(liczba[i])))
            falafele++;

    std::cout<<falafele;

    return 0;
}
